const teachers = {
    "teacher1": {
        "subjects": ["IoT", "Subject2"],
        "links": {
            "IoT": "https://docs.google.com/forms/d/e/1FAIpQLSdHh6AEYeB3FlU6NUYahsBLaKw3mwwKwt570augpm7V_EJEGg/viewform",
            "Subject2": "https://docs.google.com/forms/d/e/1FAIpQLSdK9nhuz9RFGKfC3_UVz5cIyxEKkSExaFORM_LINK_2"
        }
    },
    "teacher2": {
        "subjects": ["Subject3", "Subject4"],
        "links": {
            "Subject3": "https://docs.google.com/forms/d/e/1FAIpQLSdK9nhuz9RFGKfC3_UVz5cIyxEKkSExaFORM_LINK_3",
            "Subject4": "https://docs.google.com/forms/d/e/1FAIpQLSdK9nhuz9RFGKfC3_UVz5cIyxEKkSExaFORM_LINK_4"
        }
    }
    // Add more teachers as needed
};

function authenticate() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (teachers.hasOwnProperty(username) && password === "password") {
        displaySubjects(teachers[username]);
    } else {
        alert("Invalid credentials. Please try again.");
    }
}

function displaySubjects(teacher) {
    const subjects = teacher.subjects;
    const subjectButtonsContainer = document.getElementById("subjectButtons");
    subjectButtonsContainer.innerHTML = "";

    subjects.forEach(subject => {
        const button = document.createElement("button");
        button.textContent = subject;
        button.onclick = function() {
            goToSubjectPage(subject, teacher.links[subject]);
        };
        subjectButtonsContainer.appendChild(button);
    });

    document.getElementById("subjectContainer").style.display = "block";
    document.getElementById("loginForm").style.display = "none";
}

function goToSubjectPage(subject, formLink) {
    const qrContainer = document.createElement("div");
    qrContainer.id = "qrcode";

    const qr = qrcode(0, 'M');
    qr.addData(formLink);
    qr.make();
    const qrImg = qr.createImgTag(11); // Adjust the size multiplier here (e.g., 10 for larger size)

    qrContainer.innerHTML = qrImg;

    const backButton = document.createElement("button");
    backButton.textContent = "Back to Subjects";
    backButton.onclick = function() {
        displaySubjects(teachers[getCurrentTeacher()]);
        qrContainer.remove();
    };

    const subjectButtonsContainer = document.getElementById("subjectButtons");
    subjectButtonsContainer.innerHTML = "";
    subjectButtonsContainer.appendChild(backButton);
    subjectButtonsContainer.appendChild(qrContainer);
}


function getCurrentTeacher() {
    // You might want to implement a way to track the current teacher
    // This function returns the current teacher's username or ID
    // You can adjust this based on how you track the current teacher
    // For simplicity, let's say you have a variable storing the current teacher's username
    return "teacher1"; // Replace this with your implementation to get the current teacher
}
